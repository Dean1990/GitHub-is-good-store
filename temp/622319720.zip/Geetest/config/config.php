<?php
/**
 * Created by PhpStorm.
 * User: mr.sin
 * Date: 2017/4/9
 * Time: 下午10:23
 */
@define("CAPTCHA_ID", $options->CAPTCHA_ID);
@define("PRIVATE_KEY", $options->PRIVATE_KEY);
?>
